const fs=require('node:fs');
let html=fs.readFileSync('dist/index.html','utf8').replace(/<link rel="stylesheet" href="([^"]+)">/g,(_,file)=>'<style>'+fs.readFileSync('dist/'+file,'utf8')+'</style>').replace(/<script src="([^"]+)"><\/script>/g,(_,file)=>'<script>'+fs.readFileSync('dist/'+file,'utf8')+'</script>');
fs.writeFileSync('../First-Keys.html',html);
if(html.includes('src="app.js"')||html.includes('href="style.css"'))throw Error('External app assets remain');
console.log('Standalone app saved; script and stylesheet embedded.');
