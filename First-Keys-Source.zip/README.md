# First Keys — personal piano studio

An original browser app combining a guided first hour with a practical music studio. Inspired by general interactive-learning ideas available in flowkey and Piano Marvel. This is not a copy of their code, interface, licensed songs, or assessment systems, and is not affiliated with either company.

## Use

Open `dist/index.html` in a current desktop browser. For the portable single-file edition, run `npm run build` and open `../First-Keys.html`. Audio starts after a user gesture. Chrome/Edge are recommended for Web MIDI; hardware permissions and browser support vary. You can also serve `dist` from any static web host. MIDI may require HTTPS or localhost.

No install, API key, AI subscription or backend is required. The optional Google Fonts stylesheet needs an internet connection; system fonts work offline. Learning data is stored only in the current browser. Local-file storage support varies by browser.

## Features

- Six first-hour lessons, note and interval feedback, metronome, touch/typing/MIDI piano.
- Practice Lab: simplified public-domain melodies and one original chord exercise.
- Treble/bass practice scores, hand selection, phrase selection and repeat loops.
- Wait-mode note checking; chord pitches must arrive within a 200 ms onset window.
- Timing checks compare event gaps with the selected tempo, ±30% tolerance.
- Random C-major reading drills, local practice journal and JSON export.

Left-hand accompaniments are simple original C pulses, not reproductions of published arrangements. The sheet display uses fixed event spacing and simplified stems/rest labels, not professional engraving. A first hour aims for a short melody, not piano fluency. Timing does not grade holds, posture, finger choice, dynamics, omissions against a fixed performance clock, or piano touch. The reading drill is not SASR or a graded test. No microphone note recognition is included.

## Development

Node 22+; no npm dependencies. `npm run check`, `npm test`, `npm run build`. Tests cover phrase boundaries, hand filtering, rests, wrong notes, chord simultaneity, rhythm-aware timing and the original lesson flow. Browser visuals, sound and hardware MIDI require manual verification.

## Research and provenance

- Faber Piano Adventures: https://primerguide.pianoadventures.com/units/sitting-at-the-piano/ and https://primerguide.pianoadventures.com/units/finger-numbers/
- ABRSM Initial Grade: https://www.abrsm.org/en-au/for-learners/piano-learning/initialgrade
- Pitch feedback study: https://www.frontiersin.org/journals/behavioral-neuroscience/articles/10.3389/fnbeh.2025.1680277/full

The app is evidence-informed, not experimentally validated. The in-app Method page explains the design inferences and limitations.

## GitHub

Create a private repository named `first-keys-piano` and upload this folder's contents. Do not upload the unrelated `.openai` hosting metadata. GitHub Actions runs source and lesson checks. Static hosting is optional; making a repository private does not automatically guarantee private GitHub Pages hosting.
