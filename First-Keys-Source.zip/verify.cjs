const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync('dist/index.html','utf8'),js=fs.readFileSync('dist/app.js','utf8');
const elements=new Map();function el(id){if(!elements.has(id))elements.set(id,{textContent:'',innerHTML:'',dataset:{},value:id==='tempo'?'60':'55',checked:true,style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},addEventListener(){},append(){},querySelectorAll(){return []}});return elements.get(id)}
for(const [,id]of js.matchAll(/\$\('([^']+)'\)/g))assert.ok(html.includes('id="'+id+'"'),'Missing element '+id);
const listeners={};
const context={console,document:{getElementById:el,querySelectorAll:()=>[],querySelector:()=>null,createElement:()=>el('generated'),addEventListener(type,handler){listeners[type]=handler},activeElement:{tagName:'BODY'}},localStorage:{getItem(){return null},setItem(){}},window:{addEventListener(){},scrollTo(){}},performance:{now:()=>Date.now()},setInterval,clearInterval,setTimeout,navigator:{}};
vm.createContext(context);vm.runInContext(js,context);
vm.runInContext(`
if(lessons.length!==6)throw Error('Expected six lessons');
for(const l of lessons){if(l.notes.length!==l.fingers.length||l.notes.length!==l.beats.length)throw Error('Lesson mismatch');if(l.notes.some(n=>n<48||n>84))throw Error('Unplayable note')}
select(2);assess(60);if(position!==0||attempts!==1)throw Error('Wrong note advanced phrase');
for(const n of lessons[2].notes)assess(n);
if(runs!==1||position!==8)throw Error('Phrase completion failed');
if(document.getElementById('accuracy').textContent!=='89%')throw Error('Wrong-note accuracy incorrect');
assess(64);if(position!==1)throw Error('Replay did not restart');
select(5);if(showHints!==false)throw Error('Recall hints visible');
reset();if(position!==0||correct!==0)throw Error('Reset failed');
completed.add(0);save();
`,context);
vm.runInContext('select(0); tone=()=>{}; document.activeElement.tagName="BUTTON";',context);
listeners.keydown({key:'a',code:'KeyA',preventDefault(){}});
assert.equal(vm.runInContext('position',context),1,'Typing piano should work after clicking Start');
console.log('PASS: DOM references, six lesson sequences, playable range, wrong-note handling, accuracy, completion, replay, recall mode, reset, persistence call, typing after button focus.');
